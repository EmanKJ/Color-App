package com.example.morecolors

import android.annotation.SuppressLint
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.morecolors.databinding.ActivityMainBinding
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    //----------------------------------------
    private lateinit var myRV: RecyclerView
    private lateinit var rvAdapter: RecyclerViewAdapter
    //----------------------------------------
    lateinit var our_button: Button
    var colors= arrayOf(arrayOf(123,80,200))
    //set variables for RGB colors:
    var r=0//for read
    var g=0//for green
    var b=0//for blue



    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //access the recycler view
        myRV = this.findViewById(R.id.colors_view)
        rvAdapter = RecyclerViewAdapter(colors,this)
        myRV.adapter = rvAdapter
        myRV.layoutManager = LinearLayoutManager(this@MainActivity, LinearLayoutManager.HORIZONTAL, false)
        //--------------------------------------------------
        //define button
        our_button=findViewById(R.id.button)

        our_button.setOnClickListener() {
            set_color_value()
            set_button_color()
            colors += arrayOf(r, g, b)
            rvAdapter.updateList(colors)
            myRV.smoothScrollToPosition(colors.size)//this perform auto scroll when the user enter new operation

        }
    }



    //this function will set random value for color
    fun set_color_value()
    {
        r= Random.nextInt(0, 255)
        g= Random.nextInt(0, 255)
        b= Random.nextInt(0, 255)
    }
    //***************************
    fun set_button_color(){
        our_button.setBackgroundColor(Color.rgb(r,g,b))
    }
}