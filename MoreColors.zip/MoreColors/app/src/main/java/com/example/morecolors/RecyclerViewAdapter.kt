package com.example.morecolors
import android.annotation.SuppressLint
import android.graphics.Color
import android.text.Layout
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.morecolors.databinding.RgbColorBinding


class RecyclerViewAdapter  (private var colors: Array<Array<Int>>, private val activity: MainActivity): RecyclerView.Adapter<RecyclerViewAdapter.ItemViewHolder>() {
    class ItemViewHolder(val binding: RgbColorBinding): RecyclerView.ViewHolder(binding.root)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        return ItemViewHolder(
            RgbColorBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }
    @SuppressLint("ResourceAsColor")
    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        //val color=colors[position]
        var colorR = colors[position][0]
        var colorG = colors[position][1]
        var colorB= colors[position][2]
        var ll: View? =activity.findViewById(R.id.llMain)
        var change=true//this variable to keep track if the user want to change the color or return it to original color
        holder.binding.apply {
            textView.text= "R- $colorR \nG- $colorG\nB- $colorB"
            //textView.setTextColor(Color.rgb(colorR,colorG,colorB))
            cardView.setCardBackgroundColor(Color.rgb(colorR,colorG,colorB))
            cardView.setOnClickListener(){
                if (change){
                    if (ll != null) {
                        ll.setBackgroundColor(Color.rgb(colorR,colorG,colorB))
                    }
                    //cardView.setBackgroundColor(Color.WHITE)
                    change=false
                }
                else
                {
                    if (ll != null) {
                        ll.setBackgroundColor(Color.WHITE)
                    }
                    //cardView.setBackgroundColor(Color.rgb(colorR,colorG,colorB))
                    change=true
                }
            }

        }





    }

    //Update the list:
    fun updateList(new_colors:Array<Array<Int>>){
        colors=new_colors
        notifyDataSetChanged()

    }


    override fun getItemCount() = colors.size
}